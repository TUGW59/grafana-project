# BloomAtlas World Explorer — TAM PLUGIN PAKETİ

Bu paket **tek bir Grafana panel plugininin tam kaynak yapısıdır**. Yalnızca kaynak değişikliği değildir.

## İçeriği

- `tugcetopuz-bloomatlasworld-panel/` → orijinal Grafana scaffold + World Explorer MVP, kaynaklar, lock dosyası, testler, logo, provisioning
- `INSTALL_BLOOMATLAS.py` → **yalnızca bu plugin** klasörünü güvenli temizleyerek kurar; önceki dosyaları Git reposu dışında yedekler

## Kurulum (Windows + WSL Ubuntu)

1. ZIP'i indir. **ZIP'i açma.** Windows Dosya Gezgini ile dosyayı şuraya kopyala:

   `\\wsl$\Ubuntu-22.04\home\tugce\projects\grafana-project\`

2. VS Code içinde, WSL Ubuntu terminalinde **proje kökünden** aşağıdakileri çalıştır:

```bash
cd ~/projects/grafana-project
python3 -m zipfile -e BloomAtlas_WorldExplorer_TAM_PLUGIN.zip /tmp/bloomatlas-world-install
python3 /tmp/bloomatlas-world-install/INSTALL_BLOOMATLAS.py
cd plugins/tugcetopuz-bloomatlasworld-panel
python3 -m json.tool package.json > /dev/null && echo 'PACKAGE JSON OK'
npm run typecheck && npm run lint && npm run test:ci && npm run build
```

**`feat/world-explorer-mvp` branch'inde olmalısın.** Kurucu başka branch'te değişiklik yapmaz.

3. Derleme başarılı olunca açık Grafana'da `World Explorer Dev` dashboard'unu `Ctrl + Shift + R` ile yenile. Aynı plugin ID'si korunmuştur.

## Güvenlik ve geri dönüş

- Orijinal bozuk/plugin dosyaları `~/bloomatlas-plugin-backups/` altında tarih damgalı bir klasöre alınır.
- `node_modules/` ve `dist/` yerinde korunur. Bu, mevcut Docker bind mount'unu korur. Grafana konteyneri **silinmez veya yeniden yaratılmaz**.
- Kurucu yalnız `plugins/tugcetopuz-bloomatlasworld-panel` içeriğini değiştirir; `dashboards/`, `api/`, `data/`, `docs/`, Git branch ve commit'lerine dokunmaz.
- Kaynakların kontrolünden sonra `git status -sb` ile değişiklikleri görebilirsin. Henüz commit/push yapma.
- `npm run server` veya `docker compose up` kullanma; önceki scaffold Dockerfile sorunu devam ediyor.

## Çalışan ve henüz çalışmayan özellikler

**MVP:** harita, 12 kurgusal/demo gözlem, dört filtre, seçim, detay kartı, developer credit ve Jest birim testleri.

**Henüz yok:** canlı bilimsel veri, gerçek API, Flower Story dashboard bağlantısı, ortak Docker Compose, yayımlanmış plugin.

## Doğrulama sınırı

Bu paket orijinal kullanıcının repo ZIP'i ile daha önce hazırlanan World Explorer MVP kaynakları birleştirilerek oluşturulmuştur. JSON ve TypeScript sözdizimleri araçlarla doğrulanır; kullanıcının kendi WSL ve Grafana ortamında dört npm komutuyla işlevsel derleme sonucu ayrıca doğrulanmalıdır.
