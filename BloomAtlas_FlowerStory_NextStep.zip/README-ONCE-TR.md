# BloomAtlas Flower Story — İkinci panel / bağlantı paketi

Bu paket **çalışan World Explorer haritasını değiştirmez**. Yalnızca World Explorer içindeki devre dışı Story butonunu gerçek bağlantıya dönüştürür ve bağımsız Samira Flower Story pluginini oluşturur.

## 1. ZIP'i WSL repo köküne kopyala

Windows'ta indirdiğin `BloomAtlas_FlowerStory_NextStep.zip` dosyasını Dosya Gezgini ile `\\wsl$\Ubuntu-22.04\home\tugce\projects\grafana-project` içine kopyala. Windows UNC yolunu Ubuntu terminaline yazma.

## 2. Ubuntu terminalinde kur

```bash
cd ~/projects/grafana-project
python3 -m zipfile -e BloomAtlas_FlowerStory_NextStep.zip /tmp/bloomatlas-story-install
python3 /tmp/bloomatlas-story-install/INSTALL_FLOWER_STORY.py
```

## 3. İki plugini ayrı ayrı derle

```bash
cd ~/projects/grafana-project/plugins/samirapordugan-bloomatlasstory-panel
npm ci
npm run typecheck && npm run lint && npm run test:ci && npm run build
cd ../tugcetopuz-bloomatlasworld-panel
npm run typecheck && npm run lint && npm run test:ci && npm run build
```

`npm audit fix --force` **çalıştırma**; peer dependency uyarılarını rastgele sürüm değişikliğiyle düzeltmek yerine ileride planla.

## 4. Mevcut Grafana'yı veri kaybetmeden yeni yapılandırmayla aç

`bloomatlas-world-v2` mevcut konteynerinin `bloomatlas-grafana-v2-data` adlı Docker volume'unu kullandığı kurulum varsayılmıştır. Deployment scripti bunu kontrol eder; yanlışsa hiçbir konteyneri değiştirmez. Yeni konteynerin adı `bloomatlas-world-v3` olacaktır, eski konteyner silinmeyecektir.

```bash
bash /tmp/bloomatlas-story-install/DEPLOY_GRAFANA_3001.sh
```

`http://localhost:3001` açıldıktan sonra Grafana'da **Dashboards → New → Import** yoluyla `~/projects/grafana-project/dashboards/flower-story-dev.json` içeriğini içe aktar (dosyayı Windows Dosya Gezgini üzerinden WSL'den seçebilirsin). Ardından World Explorer Dev'deki bir çiçeği seç ve `View Flower Story →` bağlantısına bas.

## Çalışması gereken akış

World Explorer (12 demo gözlem) → çiçeğe tıkla → View Flower Story → Flower Story Dev → doğru tür + demo ay/habitat + açıkça *fictional* işaretli hikâye → Back to World Explorer.

Hikâyeler, koordinatlar ve aylar demo içeriğidir; gerçek botanik/hikâye kaynağı olarak kullanma. Gerçek veri entegrasyonu sonraki aşamadır.

## Geri dönüş

Kurulum scripti eski WorldExplorer.tsx dosyasını `~/bloomatlas-plugin-backups/flower-story-*` klasörüne yedekler. Docker yeni konteyneri açarken eski `bloomatlas-world-v2` konteynerini silmez; bir sorun olursa:

```bash
docker stop bloomatlas-world-v3
docker start bloomatlas-world-v2
```

Bu geri dönüşte iki konteyneri aynı anda başlatma (3001 portu çakışır).
