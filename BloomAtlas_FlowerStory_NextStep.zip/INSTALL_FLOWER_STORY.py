#!/usr/bin/env python3
"""Install a standalone Flower Story plugin from the existing working World Explorer scaffold.

The only modification to the working World Explorer source is its disabled Story button.
Docker, dist, node_modules, and existing Grafana databases are never changed here.
"""
from pathlib import Path
import json, shutil, subprocess, datetime, sys

ROOT = Path.home()/'projects'/'grafana-project'
OLD = ROOT/'plugins'/'tugcetopuz-bloomatlasworld-panel'
NEW = ROOT/'plugins'/'samirapordugan-bloomatlasstory-panel'
DASH = ROOT/'dashboards'/'flower-story-dev.json'
SRC = Path(__file__).resolve().parent
WORLDFILE = OLD/'src/components/WorldExplorer.tsx'

if not (ROOT/'.git').exists():
    sys.exit('ERROR: Expected repository does not exist: '+str(ROOT))
branch = subprocess.run(['git','-C',str(ROOT),'branch','--show-current'],capture_output=True,text=True,check=True).stdout.strip()
if branch != 'feat/world-explorer-mvp':
    sys.exit('ERROR: Stop. Expected branch feat/world-explorer-mvp; current branch: '+branch)
for name in ('package.json','package-lock.json','tsconfig.json','src/plugin.json'):
    if not (OLD/name).is_file(): sys.exit('ERROR: Existing World Explorer scaffold is incomplete: '+name)
try: pkg=json.loads((OLD/'package.json').read_text())
except json.JSONDecodeError: sys.exit('ERROR: World Explorer package.json not valid. No changes made.')
if pkg.get('name') != 'bloom-atlas-world':sys.exit('ERROR: Unexpected World Explorer package name; no changes made.')
if NEW.exists() or DASH.exists():
    sys.exit('ERROR: New plugin or Story dashboard already exists. Refusing to overwrite; no changes made.')
world=WORLDFILE.read_text(encoding='utf-8')
needle='<button className={st.link} type="button" disabled title="Flower Story dashboard is the next development step">View Flower Story — coming next</button>'
if needle not in world:
    sys.exit('ERROR: Expected Story placeholder button not found. WorldExplorer.tsx may have changed; no changes made.')
style='opacity:.65;cursor:not-allowed;'
if style not in world:
    sys.exit('ERROR: Expected placeholder button styling not found. No changes made.')

backup=Path.home()/'bloomatlas-plugin-backups'/('flower-story-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
backup.mkdir(parents=True,exist_ok=False)
shutil.copy2(WORLDFILE,backup/'WorldExplorer.tsx')

import tempfile
with tempfile.TemporaryDirectory(prefix='bloom-story-',dir=ROOT/'plugins') as tmp:
    staging=Path(tmp)/NEW.name
    staging.mkdir()
    # Copy only scaffold pieces, not World Explorer source or runtime folders.
    items=['.claude','.codex','.config','.cprc.json','.gitignore','.npmrc','.nvmrc','.prettierrc.js',
           'AGENTS.md','CHANGELOG.md','CLAUDE.md','GEMINI.md','LICENSE','README.md','docker-compose.yaml',
           'eslint.config.mjs','jest-setup.js','jest.config.js','package.json','package-lock.json',
           'playwright.config.ts','tsconfig.json']
    for item in items:
        source=OLD/item
        if not source.exists():continue
        dest=staging/item
        shutil.copytree(source,dest) if source.is_dir() else shutil.copy2(source,dest)
    shutil.copytree(SRC/'story-src'/'src',staging/'src')
    package=json.loads((staging/'package.json').read_text())
    package['name']='bloom-atlas-story'
    package['author']='BloomAtlas team'
    (staging/'package.json').write_text(json.dumps(package,indent=2)+'\n')
    lock=json.loads((staging/'package-lock.json').read_text())
    lock['name']='bloom-atlas-story'
    if '' in lock.get('packages',{}):lock['packages']['']['name']='bloom-atlas-story'
    (staging/'package-lock.json').write_text(json.dumps(lock,indent=2)+'\n')
    (staging/'README.md').write_text('# BloomAtlas Flower Story (MVP)\n\nIndependent Grafana panel plugin with fictional demo content. See project README for running instructions.\n')
    # Copy cleaned ready-to-test plugin only when everything is valid.
    for j in ('package.json','package-lock.json','src/plugin.json'):
        json.loads((staging/j).read_text())
    shutil.copytree(staging,NEW)

shutil.copy2(SRC/'dashboards'/'flower-story-dev.json',DASH)
world=world.replace(needle,'<a className={st.link} href={`/d/bloomatlas-story-dev/flower-story-dev?var-flowerId=${encodeURIComponent(selected.flowerId)}`}>View Flower Story →</a>')
world=world.replace(style,'text-decoration:none;display:block;text-align:center;cursor:pointer;')
WORLDFILE.write_text(world,encoding='utf-8')
print('✅ Created independent Flower Story plugin:',NEW)
print('✅ Added dashboard import file:',DASH)
print('✅ Linked World Explorer button to Flower Story with flowerId.')
print('✅ World source backup:',backup/'WorldExplorer.tsx')
print('✅ Git branch:',branch)
print('NEXT: build the Story plugin; then rebuild the World plugin.')
