#!/usr/bin/env bash
set -euo pipefail
ROOT="$HOME/projects/grafana-project"
WORLD="$ROOT/plugins/tugcetopuz-bloomatlasworld-panel"
STORY="$ROOT/plugins/samirapordugan-bloomatlasstory-panel"
CONTAINER="bloomatlas-world-v2"
NEW="bloomatlas-world-v3"
VOLUME="bloomatlas-grafana-v2-data"

echo "Checking two built plugins..."
for plugin in "$WORLD" "$STORY"; do
    test -s "$plugin/dist/module.js" || { echo "Missing dist/module.js for $plugin. Run npm run build first."; exit 1; }
done
if ! docker inspect "$CONTAINER" >/dev/null 2>&1; then
    echo "Expected existing Grafana container $CONTAINER not found; refusing to deploy."; exit 1
fi
if docker inspect "$NEW" >/dev/null 2>&1; then
    echo "New container name $NEW already exists. Refusing to overwrite."; exit 1
fi
if ! docker inspect -f '{{range .Mounts}}{{println .Name .Destination}}{{end}}' "$CONTAINER" | grep -Fq "$VOLUME /var/lib/grafana"; then
    echo "Expected persistent Grafana volume was not found; refusing to modify containers.";exit 1
fi
if [ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER")" != true ]; then
    echo "Existing $CONTAINER is not running. Please inspect Docker first.";exit 1
fi

echo "Copying both compiled plugins into persistent Grafana volume..."
for entry in "tugcetopuz-bloomatlasworld-panel:$WORLD" "samirapordugan-bloomatlasstory-panel:$STORY"; do
  name="${entry%%:*}"; src="${entry#*:}"
  docker exec "$CONTAINER" mkdir -p "/var/lib/grafana/plugins/$name"
  docker cp "$src/dist/." "$CONTAINER:/var/lib/grafana/plugins/$name/"
  docker exec "$CONTAINER" test -s "/var/lib/grafana/plugins/$name/module.js"
done

echo "Stopping old container (kept for rollback), starting new config on same persistent volume..."
docker stop "$CONTAINER" >/dev/null
if ! docker run -d \
    --name "$NEW" \
    -p 3001:3000 \
    -e GF_PLUGINS_ALLOW_LOADING_UNSIGNED_PLUGINS=tugcetopuz-bloomatlasworld-panel,samirapordugan-bloomatlasstory-panel \
    -v "$VOLUME:/var/lib/grafana" \
    grafana/grafana-enterprise:13.2.4-ubuntu; then
  echo "New instance did not start. Attempting rollback..."
  docker start "$CONTAINER" || true
  exit 1
fi

echo "✅ New Grafana container created. Old container remains stopped and available for rollback."
echo "Open http://localhost:3001 and import dashboards/flower-story-dev.json"
echo "If needed: docker stop $NEW && docker start $CONTAINER"
